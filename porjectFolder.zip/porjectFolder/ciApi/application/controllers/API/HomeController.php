<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class HomeController extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
		$this->load->model('api/HomeModel');
	}
	public function index(){
		echo "Hello nitish sir , how are you ?";
	}

	public function getAlluserData(){		
		$res = $this->HomeModel->getAllUsers();
		if(!empty($res)){
			print_r(json_encode(['code'=>'201','status'=>'success','data'=>$res]));			
		}else{
			print_r(json_encode(['code'=>'200','status'=>'failure','message'=>'data not found.']));			
		}
	}

}





?>