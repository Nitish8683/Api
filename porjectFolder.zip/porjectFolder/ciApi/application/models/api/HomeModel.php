<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class HomeModel extends CI_Model{
	
	public function getAllUsers(){
		$this->db->select();
		$this->db->from('users');
		$res = $this->db->get()->result_array();
		return $res;
	}
	
	
	
	
	
}